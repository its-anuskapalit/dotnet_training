# C# Console App — Interface Examples

This project contains **simple, assessment-friendly Console examples** for:

- `IDisposable`
- `IAsyncDisposable`
- `IComparable`
- `IComparable<T>`
- `IEquatable<T>`

---

## ✅ How to Run

### Option A: .NET CLI
```bash
cd src/InterfaceExamples
dotnet restore
dotnet run
```

### Option B: Visual Studio
1. Open folder: `src/InterfaceExamples`
2. Open `InterfaceExamples.csproj`
3. Run

---

## 1) IDisposable (Deterministic cleanup)

### Purpose
Use when your class holds resources that must be released immediately:
- Files/Streams, DB connections, sockets, unmanaged memory

### Contract
```csharp
void Dispose();
```

### Best practice
Use `using` so `Dispose()` always runs:
```csharp
using var resource = new MyResource();
```

### Demo
- `Demo_IDisposable.cs` writes to `demo-log.txt` and closes the file safely.

---

## 2) IAsyncDisposable (Async cleanup)

### Purpose
Use when cleanup itself requires `await` (async flush, async stream disposal, etc.)

### Contract
```csharp
ValueTask DisposeAsync();
```

### Best practice
Use `await using`:
```csharp
await using var resource = new MyAsyncResource();
```

### Demo
- `Demo_IAsyncDisposable.cs` simulates async cleanup.

---

## 3) IComparable (non-generic sorting)

### Purpose
Allows objects to be compared for sorting:
```csharp
int CompareTo(object obj);
```

### Notes
- Old style, not type-safe.
- Prefer `IComparable<T>` when possible.

### Demo
- `Demo_IComparable.cs` sorts Employees by Age.

---

## 4) IComparable<T> (type-safe sorting)

### Purpose
Type-safe comparison:
```csharp
int CompareTo(T other);
```

### Why better?
- No casting
- Cleaner and safer
- Faster in many cases

### Demo
- `Demo_IComparableT.cs` sorts Products by Price then Name.

---

## 5) IEquatable<T> (Equality rules for collections)

### Purpose
Defines how your objects are considered equal:
```csharp
bool Equals(T other);
```

### Where it matters?
- `HashSet<T>` (duplicate removal)
- `Dictionary<TKey,TValue>` keys
- LINQ `Distinct()`

### VERY IMPORTANT
If you implement `IEquatable<T>`, also override:
- `Equals(object)`
- `GetHashCode()`

### Demo
- `Demo_IEquatableT.cs` shows `HashSet<Customer>` treating same `Id` as duplicate.

---

## ✅ Quick Exam Hints

- `using`  => `IDisposable`
- `await using` => `IAsyncDisposable`
- Sorting custom types => `IComparable<T>`
- HashSet/Dictionary keys => `IEquatable<T>` + consistent `GetHashCode()`
