using System;
using System.Collections.Generic;

namespace InterfaceExamples;

/// <summary>
/// IComparable<T> is the type-safe version of IComparable.
/// This demo sorts products by Price (ascending), then by Name.
/// </summary>
public static class Demo_IComparableT
{
    public static void Run()
    {
        Console.WriteLine("---- 4) IComparable<T> Demo ----");

        var products = new List<Product>
        {
            new Product("Mouse", 799m),
            new Product("Keyboard", 1299m),
            new Product("USB Cable", 299m),
            new Product("Mouse", 699m)
        };

        products.Sort(); // uses CompareTo(Product)

        Console.WriteLine("Sorted by Price, then Name:");
        foreach (var p in products)
            Console.WriteLine($"- {p.Name} (₹{p.Price})");

        Console.WriteLine();
    }

    private sealed class Product : IComparable<Product>
    {
        public string Name { get; }
        public decimal Price { get; }

        public Product(string name, decimal price)
        {
            Name = name;
            Price = price;
        }

        public int CompareTo(Product? other)
        {
            if (other is null) return 1;

            int byPrice = Price.CompareTo(other.Price);
            if (byPrice != 0) return byPrice;

            return string.Compare(Name, other.Name, StringComparison.Ordinal);
        }
    }
}
