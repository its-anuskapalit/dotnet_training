using System;
using System.Threading.Tasks;

namespace InterfaceExamples;

/// <summary>
/// IAsyncDisposable is used when cleanup requires async work (flush network buffers, async stream dispose, etc.).
/// This demo simulates an async resource that must be disposed asynchronously.
/// </summary>
public static class Demo_IAsyncDisposable
{
    public static async Task RunAsync()
    {
        Console.WriteLine("---- 2) IAsyncDisposable Demo ----");

        // ✅ await using ensures DisposeAsync() is called automatically.
        await using (var resource = new AsyncResource())
        {
            await resource.DoWorkAsync();
        }

        Console.WriteLine("Explanation: DisposeAsync() ran after the work completed.\n");
    }

    private sealed class AsyncResource : IAsyncDisposable
    {
        private bool _disposed;

        public async Task DoWorkAsync()
        {
            if (_disposed) throw new ObjectDisposedException(nameof(AsyncResource));

            Console.WriteLine("AsyncResource: doing async work...");
            await Task.Delay(300);
            Console.WriteLine("AsyncResource: work completed.");
        }

        public async ValueTask DisposeAsync()
        {
            if (_disposed) return;

            Console.WriteLine("AsyncResource: disposing asynchronously (simulated)...");
            await Task.Delay(300); // simulate async cleanup
            _disposed = true;
            Console.WriteLine("AsyncResource: disposed.");
        }
    }
}
