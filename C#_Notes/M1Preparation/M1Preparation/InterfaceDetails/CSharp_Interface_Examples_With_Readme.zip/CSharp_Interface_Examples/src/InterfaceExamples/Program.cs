using System;
using System.Threading.Tasks;

namespace InterfaceExamples;

class Program
{
    static async Task Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        PrintBanner();

        Demo_IDisposable.Run();
        await Demo_IAsyncDisposable.RunAsync();
        Demo_IComparable.Run();
        Demo_IComparableT.Run();
        Demo_IEquatableT.Run();

        Console.WriteLine("\n✅ Done. Press ENTER to exit...");
        Console.ReadLine();
    }

    static void PrintBanner()
    {
        Console.WriteLine("==============================================");
        Console.WriteLine(" C# Interface Examples (Console App)");
        Console.WriteLine(" IDisposable | IAsyncDisposable | IComparable");
        Console.WriteLine(" IComparable<T> | IEquatable<T>");
        Console.WriteLine("==============================================\n");
    }
}
