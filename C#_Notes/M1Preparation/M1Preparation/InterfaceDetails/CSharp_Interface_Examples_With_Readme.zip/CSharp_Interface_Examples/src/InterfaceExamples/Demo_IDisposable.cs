using System;
using System.IO;

namespace InterfaceExamples;

/// <summary>
/// IDisposable is used when a type owns unmanaged resources (files, streams, DB connections, sockets...).
/// This demo writes logs to a file and closes the file handle safely.
/// </summary>
public static class Demo_IDisposable
{
    public static void Run()
    {
        Console.WriteLine("---- 1) IDisposable Demo ----");

        string logPath = Path.Combine(AppContext.BaseDirectory, "demo-log.txt");

        // ✅ BEST PRACTICE: use 'using' so Dispose() is called automatically even if an exception occurs.
        using (var logger = new FileLogger(logPath))
        {
            logger.Write("Application started");
            logger.Write("Processing...");
            logger.Write("Application finished");
        }

        Console.WriteLine($"Log written to: {logPath}");
        Console.WriteLine("Explanation: FileLogger.Dispose() closed the StreamWriter.\n");
    }

    private sealed class FileLogger : IDisposable
    {
        private StreamWriter? _writer;
        private bool _disposed;

        public FileLogger(string path)
        {
            _writer = new StreamWriter(path, append: true);
            _writer.AutoFlush = true;
        }

        public void Write(string message)
        {
            if (_disposed) throw new ObjectDisposedException(nameof(FileLogger));
            _writer!.WriteLine($"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {message}");
        }

        // The Dispose pattern: free resources deterministically.
        public void Dispose()
        {
            if (_disposed) return;

            _writer?.Dispose();   // closes file handle
            _writer = null;

            _disposed = true;
        }
    }
}
