using System;
using System.Collections.Generic;

namespace InterfaceExamples;

/// <summary>
/// IComparable (non-generic) allows objects to be compared and sorted (CompareTo(object)).
/// This demo sorts employees by Age using IComparable.
/// </summary>
public static class Demo_IComparable
{
    public static void Run()
    {
        Console.WriteLine("---- 3) IComparable (non-generic) Demo ----");

        var employees = new List<Employee>
        {
            new Employee("Meena", 28),
            new Employee("Arjun", 24),
            new Employee("Karthik", 30)
        };

        employees.Sort(); // uses CompareTo

        Console.WriteLine("Sorted by Age (ascending):");
        foreach (var e in employees)
            Console.WriteLine($"- {e.Name} ({e.Age})");

        Console.WriteLine("Note: Prefer IComparable<T> in modern code (type-safe).\n");
    }

    private sealed class Employee : IComparable
    {
        public string Name { get; }
        public int Age { get; }

        public Employee(string name, int age)
        {
            Name = name;
            Age = age;
        }

        public int CompareTo(object? obj)
        {
            if (obj is null) return 1; // current instance > null
            if (obj is not Employee other) throw new ArgumentException("Object is not an Employee");

            return Age.CompareTo(other.Age); // ascending
        }
    }
}
