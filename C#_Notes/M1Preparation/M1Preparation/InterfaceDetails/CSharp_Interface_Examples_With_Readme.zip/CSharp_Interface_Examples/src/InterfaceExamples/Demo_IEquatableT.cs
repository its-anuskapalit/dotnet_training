using System;
using System.Collections.Generic;

namespace InterfaceExamples;

/// <summary>
/// IEquatable<T> defines strong equality semantics (Equals(T other)).
/// Very useful for HashSet<T>, Dictionary keys, Distinct(), etc.
/// This demo shows how equality affects HashSet behavior.
/// </summary>
public static class Demo_IEquatableT
{
    public static void Run()
    {
        Console.WriteLine("---- 5) IEquatable<T> Demo ----");

        var set = new HashSet<Customer>
        {
            new Customer(101, "Meena"),
            new Customer(102, "Arjun"),
            new Customer(101, "Meena (Duplicate with same Id)") // same Id => treated as same customer
        };

        Console.WriteLine($"HashSet count (should be 2): {set.Count}");
        foreach (var c in set)
            Console.WriteLine($"- {c.Id} | {c.Name}");

        Console.WriteLine("Explanation: Customers are equal if Id is equal.\n");
    }

    private sealed class Customer : IEquatable<Customer>
    {
        public int Id { get; }
        public string Name { get; }

        public Customer(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public bool Equals(Customer? other)
        {
            if (other is null) return false;
            if (ReferenceEquals(this, other)) return true;

            return Id == other.Id;
        }

        public override bool Equals(object? obj) => Equals(obj as Customer);

        public override int GetHashCode() => Id.GetHashCode();
    }
}
